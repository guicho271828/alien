:-cl(lcs),go.
:-cl(matrix),go.
:-cl(lcs1),go.
:-cl(obst),go.
:-cl(knapsack),go.
