:-consult(array),go.
:-consult(assign),go.
:-consult(bqueens),go.
:-consult(ex1),go.
:-consult(length_sum),go.
:-consult(magic),go.
:-consult(perms),go.
:-consult(qsort),go.
:-consult(queens),go.
:-consult(staircase),go.
:-consult(triangle_matrix),go.

