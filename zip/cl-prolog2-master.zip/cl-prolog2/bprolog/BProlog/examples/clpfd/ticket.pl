go:-
    [S,A]
