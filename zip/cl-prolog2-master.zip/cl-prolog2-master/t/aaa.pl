'parent-of'('luke-skywalker','anakin-skywalker').

program :- write_canonical('parent-of'('luke-skywalker','anakin-skywalker')),
           halt.

:- initialization(program).

